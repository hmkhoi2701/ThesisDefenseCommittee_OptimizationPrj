from time import perf_counter
with open('data_size_100.txt','r') as f :
  m = []
  for i in f:
    m.append(list (map(int, i.split())))
  [N,M,K] = m[0]
  [a, b, c, d, e, f] = m[1]
  t = m[-1]
  s = (m[2:2+N])
  g = (m[N+2:N+M+2])

start = perf_counter()
#student divide
student_list = [x+1 for x in range(N)]
divide = [[[],[]] for _ in range(K)]
for room in range(K):
  x = student_list[0]-1
  divide[room][0].append(student_list.pop(0))
  queue = []
  for i in student_list:
    if int(s[x][i-1]) > 1:
      queue.append(i)
  queue.sort(reverse=True)
  for i in range(min(len(queue),a-1)):
    divide[room][0].append(queue[i])
    student_list.remove(queue[i])


for room in range(K):
  if len(divide[room][0])<b and len(student_list)!=0:
    if s[divide[room][0][0]-1][student_list[0]-1]>1:
      divide[room][0].append(student_list.pop(0))
for room in range(K):
  if len(divide[room][0])<b and len(student_list)!=0:
      divide[room][0].append(student_list.pop(0))


#prof divide:
prof_list = [x+1 for x in range(M)]
for room in range(K):
  cand = []
  for prof in prof_list:
    if g[prof-1][divide[room][0][0]-1]>1:
      cand.append(prof)
  cand.sort(reverse=True)
  for i in range(min(len(cand),c)):
    divide[room][1].append(cand[i])
    prof_list.remove(cand[i])

for room in range(K):
  if len(divide[room][1])<d and len(prof_list)!=0:
    if g[prof_list[0]-1][divide[room][0][0]-1]>1:
      divide[room][1].append(prof_list.pop(0))
for room in range(K):
  if len(divide[room][1])<d and len(prof_list)!=0:
      divide[room][1].append(prof_list.pop(0))

sum = 0
for room in range(K):
  for i in range(len(divide[room][0])-1):
    for j in range(i+1,len(divide[room][0])):
      sum+= s[divide[room][0][i]-1][divide[room][0][j]-1]
  for i in range(len(divide[room][0])):
    for j in range(len(divide[room][1])):
      sum+= g[divide[room][1][j]-1][divide[room][0][i]-1]
def printSolution():
  string = ''
  for i in range(K):
    string += 'Council' + '\t' + str(i + 1) + '\n' + '______________' + '\n'
    for student in sorted(divide[i][0]):
      string += 'Student' + '\t' + str(student) + '\n'
    string += '______________' + '\n'
    for teacher in sorted(divide[i][1]):
      string += 'Teacher' + '\t' + str(teacher) + '\n'
    string += '\n' + '\n'
  print(string) 
  print('Total value of similarity: ' + '\t' + str(sum))
  
  min_e = float('inf')
  min_f = float('inf')

  for m in range(K):
    for student1 in divide[m][0]:
      for student2 in divide[m][0]:
        if student1 != student2:
          min_e = min(min_e, s[student1 - 1][student2 - 1])
    for student in divide[m][0]:
      for teacher in divide[m][1]:
        min_f = min(min_f, g[teacher - 1][student - 1])
  print('The e_value: ', min_e)
  print('The f_value: ', min_f)

printSolution()
end = perf_counter()
print('Time :'+str(end-start),'s' +'\n' +'____________________________________')
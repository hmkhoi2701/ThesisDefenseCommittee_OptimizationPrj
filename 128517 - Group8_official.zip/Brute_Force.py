from itertools import combinations
from time import perf_counter
def input_data(filename):
    with open(filename) as text:
        [N, M, K] = [int(x) for x in text.readline().split()]
        [a, b, c, d, e, f] = [int(x) for x in text.readline().split()]
        s = [[0 for x in range(N + 1)]]
        for i in range(N):
            r = [int(x) for x in text.readline().split()]
            s.append([0] + r)
        g = [[0 for x in range(N + 1)]]
        for j in range(1, M + 1):
            r = [int(x) for x in text.readline().split()]
            g.append([0] + r) 
        t = [0] + [int(x) for x in text.readline().split()]
    return N, M, K, a, b, c, d, e, f, s, g, t 

N, M, K, a, b, c, d, e, f, s, g, t = input_data('.\data_size_14.txt')
start = perf_counter()
class Council(object):
    global s, g 
    def __init__(self, m, teacher = [], student = []):
        self.Teacher = teacher # contains index of teacher in the council
        self.Student = student # contains index of teacher in the council
        self.Order = m          # the order of the council
        self.Pre_Council = None 
    def similarity_value_ss(self): # the total similarity value between each pair of projects 
        total_ss = 0
        for i in range(len(self.Student) - 1):
            for j in range(i + 1, len(self.Student)):
                total_ss += s[self.Student[i]][self.Student[j]] 
        return total_ss
    def similarity_value_ts(self): # the total similarity value between each pair of teachers and students
        total_ts = 0
        for j in self.Teacher:
            for i in self.Student:
                total_ts += g[j][i]
        return total_ts
    def total_similarity(self):
        return self.similarity_value_ts() + self.similarity_value_ss()
    def e_value(self): # return the minimum similarity value of each pair of students
        e = float('inf') 
        for i in range(len(self.Student) - 1):
            for j in range(i + 1, len(self.Student)):
                e = min(e, s[self.Student[i]][self.Student[j]])
        return e 
    def f_value(self): # return the minimum similarity value between teacher and student in the council
        f = float('inf') 
        for j in self.Teacher:
            for i in self.Student:
                f = min(f, g[j][i])
        return f 
    def __str__(self): # return the name of the council and its teachers and students 
        string = 'Council: ' + '\t' + str(self.Order) + '\n' + ' ' + '\n'
        for x in self.Student:
            string += 'Student ' + '\t' + str(x) + '\n'
        string += '____________________' + '\n'
        for y in self.Teacher:
            string += 'Teacher ' + '\t' + str(y) + '\n'
        string += '   ' + '\n'
        return string 

#set variables 
current_solution = [0 for x in range(K + 1)] # list containt councils 
optimal_solution = [0 for x in range(K + 1)] 
opt_value = -float('inf') 

def Subsets_of_set(lst: list, num): # return subset with length 'num' of the given list
    set_of_ids = combinations(range(len(lst)), num)
    list_of_subsets = []
    for id in set_of_ids:
        subset = []
        for i in id:
            subset.append(lst[i])
        list_of_subsets.append(sorted(subset))
    return list_of_subsets
def check_valid_council(C: Council):
    for j in C.Teacher:
        for i in C.Student:
            if j == t[i]:
                return False
    if a <= len(C.Student) <= b and c <= len(C.Teacher) <= d and C.e_value() >= e and C.f_value() >= f:
        return True 
    else:
        return False
        
def Next_Councils(m, current_solution):
    if m == K:
        return []
    list_student = [x for x in range(1, N + 1)]
    list_teacher = [x for x in range(1, M + 1)]
    for i in range(1, m + 1):
        for student in current_solution[i].Student:
            list_student.remove(student)
        for teacher in current_solution[i].Teacher:
            list_teacher.remove(teacher)        
    if m == K - 1:
        C = Council(m + 1)
        C.Teacher = list_teacher[:]
        C.Student = list_student[:]
        if check_valid_council(C):
            return [C]
        else:
            return []
    if len(list_student) >= a * (K - m) and len(list_teacher) >= c * (K - m):
        rs = []
        max_student = len(list_student) - a * (K - m - 1)
        max_student = min(max_student, b)
        max_teacher = len(list_teacher) - c * (K - m - 1)
        max_teacher = min(max_teacher, d)
        for num_student in range(a, max_student + 1):
            for group_of_students in Subsets_of_set(list_student, num_student):
                C1 = Council(0, [], group_of_students)
                if C1.e_value() < e: 
                    continue 
                for num_teacher in range(c, max_teacher + 1):
                    for group_of_teachers in Subsets_of_set(list_teacher, num_teacher):
                        C2 = Council(0, group_of_teachers, [])
                        if C2.f_value() < f:
                            continue 
                        rs.append(Council(m + 1, group_of_teachers, group_of_students))
        return [x for x in rs if check_valid_council(x)] 
    else:
        return []
def total_similarity_of_solution(solution: list):
    total = 0
    for x in solution:
        if x != 0:
            total += x.total_similarity()
    return total 
def min_e_value_of_solution(solution):
    e_ = float('inf')
    for i in range(1, K + 1):
        e_ = min(solution[i].e_value(), e_)
    return e_ 
def min_f_value_of_solution(solution):
    f_ = float('inf')
    for i in range(1, K + 1):
        f_ = min(f_, solution[i].f_value())
    return f_

def printSolution():
    print('The optimal total value of similarity: ', opt_value)
    print('The maximum e_value: ', min_e_value_of_solution(optimal_solution))
    print('The maximum f_value: ', min_f_value_of_solution(optimal_solution))
    for m in range(1, K + 1):
        print(optimal_solution[m])
    

def Try(m):
    global current_solution, opt_value, optimal_solution 
    Candidate = Next_Councils(m - 1, current_solution)[:]
    for y in Candidate:
        current_solution[m] = y 
        if m == K:
            if total_similarity_of_solution(current_solution) > opt_value:
                opt_value = total_similarity_of_solution(current_solution)
                optimal_solution = current_solution[:]  
            elif total_similarity_of_solution(current_solution) == opt_value:
                total1 = min_e_value_of_solution(optimal_solution) + min_f_value_of_solution(optimal_solution)
                total2 = min_f_value_of_solution(current_solution) + min_e_value_of_solution(current_solution)
                if total1 < total2:
                    optimal_solution = current_solution[:]
        else:
            Try(m + 1)
        current_solution[m] = 0
        

def Run():
    Try(1)
    printSolution()
Run()
end= perf_counter()
print('time',end-start)
